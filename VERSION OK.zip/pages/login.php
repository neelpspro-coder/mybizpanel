<?php
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if ($email && $password) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['role'] = $user['role'];
                
                // Log de connexion (si la table existe)
                try {
                    $stmt2 = $pdo->prepare("INSERT INTO activity_logs (id, user_id, action, page, created_at) VALUES (?, ?, ?, ?, NOW())");
                    $stmt2->execute([uniqid('log_', true), $user['id'], 'login', 'login']);
                } catch (Exception $e) {
                    // Ignorer si la table n'existe pas encore
                }
                
                // Debug : vérifier les sessions
                error_log("Session data: " . print_r($_SESSION, true));
                
                // Essayer différentes redirections
                // Option 1 : Vers un paramètre
                header('Location: ?page=dashboard');
                exit;
                
                // Option 2 : Vers un fichier (décommentez si nécessaire)
                // header('Location: dashboard.php');
                
                // Option 3 : URL complète (décommentez si nécessaire)
                // header('Location: ' . $_SERVER['HTTP_HOST'] . '/dashboard.php');
                
                // Debug : vérifier si la redirection est envoyée
                error_log("Redirection envoyée vers dashboard");
                exit;
            } else {
                $error = "Email ou mot de passe incorrect";
                error_log("Login failed for email: " . $email);
            }
        } catch (Exception $e) {
            $error = "Erreur de connexion";
            error_log("Database error: " . $e->getMessage());
        }
    } else {
        $error = "Veuillez remplir tous les champs";
    }
}

// Debug : vérifier si on est déjà connecté
if (isset($_SESSION['user_id'])) {
    error_log("User already logged in: " . $_SESSION['user_id']);
    // Si déjà connecté, rediriger
    header('Location: href="?page=dashboard"');
    exit;
}
?>

<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-500 to-purple-700">
    <div class="max-w-md w-full space-y-8 p-8">
        <div class="bg-white rounded-2xl shadow-2xl p-8">
            <!-- Logo et titre -->
            <div class="text-center mb-8">
                <div class="mx-auto w-16 h-16 bg-gradient-to-r from-violet-500 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl mb-4">
                    M
                </div>
                <h2 class="text-3xl font-bold text-gray-900">MyBizPanel</h2>
                <p class="text-gray-600 mt-2">Connectez-vous à votre espace</p>
                <p class="text-xs text-gray-400 mt-1">By Neelps</p>
            </div>

            <!-- Debug info (à retirer en production) -->
            <?php if (isset($_GET['debug'])): ?>
            <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-6 text-xs">
                <strong>Debug Info:</strong><br>
                Session ID: <?= session_id() ?><br>
                Current Page: <?= $_GET['page'] ?? 'none' ?><br>
                User ID in session: <?= $_SESSION['user_id'] ?? 'none' ?>
            </div>
            <?php endif; ?>

            <!-- Message d'erreur -->
            <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= sanitizeOutput($error) ?>
            </div>
            <?php endif; ?>

            <!-- Formulaire de connexion -->
            <form method="POST" class="space-y-6">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-envelope mr-2 text-violet-500"></i>
                        Adresse email
                    </label>
                    <input type="email" id="email" name="email" required 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                           placeholder="votre@email.com"
                           value="<?= sanitizeOutput($_POST['email'] ?? '') ?>">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-lock mr-2 text-violet-500"></i>
                        Mot de passe
                    </label>
                    <input type="password" id="password" name="password" required 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                           placeholder="••••••••">
                </div>

                <button type="submit" 
                        class="w-full bg-gradient-to-r from-violet-500 to-purple-600 text-white py-3 px-4 rounded-lg font-medium hover:from-violet-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 shadow-lg">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Se connecter
                </button>
            </form>

        </div>
        
        <!-- Footer -->
        <div class="text-center text-white/80">
            <p class="text-sm">© 2025 MyBizPanel by Neelps - Système de gestion collaborative</p>
        </div>
    </div>
</div>